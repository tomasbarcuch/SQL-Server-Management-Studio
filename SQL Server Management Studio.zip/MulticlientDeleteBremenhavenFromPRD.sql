select id from location where code = 'Hub Bremerhaven'

delete from zone where locationid = '036db603-7378-44f9-8ab1-e78a8ca28c49'
delete from location where id = '036db603-7378-44f9-8ab1-e78a8ca28c49'


