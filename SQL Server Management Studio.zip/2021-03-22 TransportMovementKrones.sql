select 
AL.Type, 
Year(AL.Created) 'Year',
DATEPART(isoWK,Al.Created) as 'Week', 
Al.Created, Al.[Location], 
Al.bin as Target,
 HU.Code,
 HUT.Text as HandlingUnitType,
 HU.Collinumber,
 HU.Length/10.0 'Length',
 HU.Width/10.0 'Width',
 HU.Height/10.0 'Height',
 HU.Netto,
 HU.Brutto, 
 Dimensions.Project, 
 Dimensions.[Order], 
 Dimensions.Commission 
 from (
select HandlingUnitId,'Movement' as Type, DATA.Created, L.Name Location, B.Code Bin FROM
(
select 
MIN(WE.Created) as Created,
WE.HandlingUnitId,
WE.LocationId,
WE.BinId

from WarehouseEntry WE
inner join BusinessUnitPermission BUP on BUP.HandlingUnitId = WE.HandlingUnitId
inner join BusinessUnit BU on BUP.BusinessUnitId = BU.Id and BU.name in ('KRONES GLOBAL')
inner join [Location] L on WE.LocationId = L.id and WE.QuantityBase > 0
inner join BusinessUnitPermission BUL on L.id = BUL.LocationId and BUL.BusinessUnitId in (select id from BusinessUnit where name = 'Deufol Hamburg Rosshafen')

group by 

WE.HandlingUnitId,
WE.LocationId,
WE.BinId
) DATA
--inner join HandlingUnit HU on DATA.HandlingUnitId = HU.Id
inner join [Location] L on DATA.LocationId = L.Id
left join Bin B on DATA.BinId = B.id


union

select SL.HandlingUnitId, Case SH.[Type] when 0 then 'Loading' else 'Unloading' end as Type,REL.Released, Lfrom.Name, SH.ToAddressName FROM
 ShipmentLine SL
inner join ShipmentHeader SH on SL.ShipmentHeaderId = SH.Id
inner join BusinessUnitPermission BUP on BUP.HandlingUnitId = SL.HandlingUnitId
inner join BusinessUnit BU on BUP.BusinessUnitId = BU.Id and BU.name in ('KRONES GLOBAL')
left join [Location] Lto on SH.ToLocationId = Lto.id
left join [Location] Lfrom on SH.FromLocationId = Lfrom.id

inner join (
Select min(WFE.Created) as Released,WFE.EntityId 
from WorkflowEntry WFE where WFE.StatusId = 'd5f9a11d-d822-4a71-9366-898dc40b1bee'
group by Wfe.EntityId) REL on SH.id = REL.EntityId

where SL.[Status] <> 0
and (
Lfrom.id in (Select LocationId from BusinessUnitPermission BUP where BUP.BusinessUnitId =(select id from BusinessUnit where name = 'Deufol Hamburg Rosshafen'))
OR
Lto.id in (Select LocationId from BusinessUnitPermission BUP where BUP.BusinessUnitId =(select id from BusinessUnit where name = 'Deufol Hamburg Rosshafen'))
)


) AL 

inner join HandlingUnit HU on Al.HandlingUnitId = HU.id
--left join HandlingUnitType HUT on HU.TypeId = HUT.Id
left join Translation HUT on HU.TypeId = HUT.EntityId and HUT.[Language] = 'de' and HUT.[Column] = 'Code'
--dimensions
left join  (
select D.name,DV.Content as Content, edvr.EntityId from DimensionValue DV 
inner join Dimension D on DV.DimensionId = D.id 
inner join EntityDimensionValueRelation EDVR on DV.Id = EDVR.DimensionValueId
inner join DimensionField DF on D.id = DF.DimensionId

where D.name in ('Project','Order','Commission')
) SRC
PIVOT (max(src.Content) for src.Name  in ([Project],[Order],[Commission])
        ) as Dimensions on HandlingUnitId = Dimensions.EntityId

where Al.Created between '2021-04-01' and '2021-04-30'

--where AL.Code = '2022000007451054'
order by HU.Code, al.Created

