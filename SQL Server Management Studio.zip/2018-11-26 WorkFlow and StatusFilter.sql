SELECT 
bu.name bu, 
p.name permission,
isnull(t_old.Text,s_old.name) olds,
isnull(t_new.text,s_new.name) news,
w.entity,
case w.entity
when 2 then 'Handling Unit 2'
when 7 then 'Dimension'
when 11 then 'Handlint Unit'
when 15 then 'Loose Part'
when 31 then 'Shipment Header'
when 35 then 'Packing Order Header'
when 48 then 'Service Line'
else cast(w.entity as varchar) end as 'entity name',
w.action,
case w.Action
when 0 then 'none'
when 1 then 'Inbound'
when 2 then 'Outbound'
when 3 then 'Transfer'
when 4 then 'Movement'
when 5 then 'Packing'
when 6 then 'Unpacking'
when 7 then 'Loading'
when 8 then 'Packing In'
when 9 then 'Unpacking From'
when 10 then 'Unloading'
when 11 then 'Loading To'
when 13 then 'Loaded All'
when 14 then 'Unloaded All'
when 16 then 'Printing'
when 17 then 'Change Status'
when 21 then 'Assigned'
when 22 then 'Packed All'
when 24 then 'Assign Value'
else cast(w.action as varchar) end as 'action name',
isnull(case SF.Action
when 0 then 'none'
when 1 then 'Inbound'
when 2 then 'Outbound'
when 3 then 'Transfer'
when 4 then 'Movement'
when 5 then 'Packing'
when 6 then 'Unpacking'
when 7 then 'Loading'
when 8 then 'Packing In'
when 9 then 'Unpacking From'
when 10 then 'Unloading'
when 11 then 'Loading To'
when 13 then 'Loaded All'
when 14 then 'Unloaded All'
when 16 then 'Printing'
when 17 then 'Change Status'
when 21 then 'Assigned'
when 22 then 'Packed All'
when 24 then 'Assign Value'
else cast(sf.action as varchar) end,'') as 'filter action name',
s_old.position old_pos,
s_new.position new_pos 
  FROM [dbo].[Workflow] w
  inner join dbo.Permission p on w.PermissionId = p.id
  inner join BusinessUnitPermission BUP on W.id = BUP.WorkflowId
  inner join dbo.businessunit bu on BUP.BusinessUnitId = bu.id
  inner join dbo.status s_old on w.oldstatusid = s_old.id
  inner join dbo.status s_new on w.newstatusid = s_new.id
  left join StatusFilter SF on W.OldStatusId = SF.StatusId
  left join BusinessUnitPermission BUPsf on SF.id = BUPsf.StatusFilterId and bup.BusinessUnitId = bupsf.BusinessUnitId
   left join Translation t_new on s_new.Id = t_new.EntityId and t_new.[Language] = 'de'
left join Translation t_old on s_old.Id = t_old.EntityId and t_old.[Language] = 'de'