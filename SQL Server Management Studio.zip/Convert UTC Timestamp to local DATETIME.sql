SELECT 
dbo.ShipmentHeader.LoadingDate,
CONVERT(datetime, 
               SWITCHOFFSET(CONVERT(datetimeoffset, 
                                    dbo.ShipmentHeader.LoadingDate), 
                            DATENAME(TzOffset, SYSDATETIMEOFFSET()))) 
       AS LoadingDateInLocalTime
       ,GETUTCDATE()
FROM dbo.ShipmentHeader
